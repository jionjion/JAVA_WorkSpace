CREATE PROCEDURE sp_select_count(OUT p_count INT(10))
  BEGIN
	select count(*) into p_count from goddess;
END;
