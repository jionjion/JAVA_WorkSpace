CREATE PROCEDURE sp_select_nofilter()
  BEGIN
	select * from goddess;
END;
