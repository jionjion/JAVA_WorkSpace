CREATE PROCEDURE sp_select_filter(IN p_name VARCHAR(20))
  BEGIN
	IF p_name IS NULL OR p_name = '' THEN
		select * from goddess;
	else
		select * from goddess where user_name like CONCAT('%',p_name,'%');
	end if;
END;
