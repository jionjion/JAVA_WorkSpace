CREATE package myPackage as
  type myCursor is ref cursor;                    --自定义数据类型
  procedure queryEmpList(dno in number,empList out myCursor);      --声明存储过程
end myPackage;
/
