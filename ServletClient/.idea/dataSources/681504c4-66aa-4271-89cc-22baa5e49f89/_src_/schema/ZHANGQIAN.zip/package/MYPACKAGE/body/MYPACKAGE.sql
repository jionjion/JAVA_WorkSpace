CREATE package body myPackage as
  procedure queryEmpList(dno in number,empList out myCursor) as    --存储过程
  begin
    open empList for select * from emp where deptno = dno;         --select语句查询的结果由游标表示  打开游标.for表示代指的结果集
  end queryEmpList;         --表示存储过程的结束
end myPackage;
/
