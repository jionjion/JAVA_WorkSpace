CREATE VIEW EMP_VIEW AS select empno,ename,job,sal from emp
order by empno
/
