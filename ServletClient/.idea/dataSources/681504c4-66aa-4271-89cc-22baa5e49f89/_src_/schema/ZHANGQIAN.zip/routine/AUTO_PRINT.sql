CREATE procedure auto_print as 
  message varchar2(20); --声明变量不需要declare关键字
begin
  message := '执行';
  insert into auto_print_log(ID,message) values(auto_print_s.nextval,message);
  dbms_output.put_line('自动执行语句.....'||message);
end;
/
