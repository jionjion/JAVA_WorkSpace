CREATE procedure raiseSalary(eno in number)
as
   --定义一个变量保存之前的薪水
  psal emp.sal%type;
begin
  select sal into psal from emp where empno = eno;
  update emp set sal=sal+100 where empno=eno;  --注意,这里一般不提交数据库
  dbms_output.put_line('涨前'||psal||'涨后'||(psal+100));
end;
/
