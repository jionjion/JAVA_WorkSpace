CREATE procedure p_test as 
begin 
insert into test values(sysdate); 
end;
/
