CREATE procedure sayHelloWorld
as--说明部分(不能省略)
begin
  dbms_output.put_line('hello world');
end;
/
