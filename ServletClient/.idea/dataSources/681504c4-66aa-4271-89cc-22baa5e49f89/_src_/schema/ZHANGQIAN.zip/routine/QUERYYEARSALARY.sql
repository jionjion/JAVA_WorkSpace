CREATE function queryYearSalary(eno in number) return number
as
 psal emp.sal%type;
 pcomm emp.comm%type;
begin
  select sal,comm into psal,pcomm from emp where empno=eno;
  return psal*12+nvl(pcomm,0); --滤空,在有空的表达式中,默认结果为空,因此需要滤空函数将其替换为0
end;
/
